require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

const Servico = require('./models/Servico');
const Cliente = require('./models/Cliente');
const Pedido = require('./models/Pedido');

const app = express();
app.use(cors());
app.use(express.json());

// Opcionalmente serve os arquivos estáticos do Front-End direto em http://localhost:3000
app.use(express.static(path.join(__dirname, '..', 'Front Alva')));

// 1. Conexão com o MongoDB Atlas
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ Conectado ao MongoDB Atlas (AlvaLavanderia)!'))
  .catch((err) => console.error('⚠️ Aviso de conexão MongoDB Atlas (verifique seu arquivo .env):', err.message));

/* ==========================================================
   ROTAS DE SERVIÇOS / CATÁLOGO (Admin e Página de Preços)
   ========================================================== */

app.get('/api/produtos', async (req, res) => {
  try {
    const servicos = await Servico.find().sort({ id: 1 });
    res.json(servicos);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

app.post('/api/produtos/seed', async (req, res) => {
  try {
    const count = await Servico.countDocuments();
    if (count === 0 && Array.isArray(req.body)) {
      await Servico.insertMany(req.body);
      return res.status(201).json({ mensagem: 'Catálogo inicial de 36 itens gravado no MongoDB Atlas!' });
    }
    res.json({ mensagem: 'Catálogo já possui itens cadastrados no banco.' });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

app.post('/api/produtos', async (req, res) => {
  try {
    const ultimo = await Servico.findOne().sort({ id: -1 });
    const novoId = req.body.id || (ultimo ? ultimo.id + 1 : 1);
    const novoServico = await Servico.create({ ...req.body, id: novoId });
    res.status(201).json(novoServico);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
});

app.put('/api/produtos/:id', async (req, res) => {
  try {
    const atualizado = await Servico.findOneAndUpdate(
      { id: Number(req.params.id) },
      req.body,
      { new: true, upsert: true }
    );
    res.json(atualizado);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
});

app.patch('/api/produtos/:id/status', async (req, res) => {
  try {
    const atualizado = await Servico.findOneAndUpdate(
      { id: Number(req.params.id) },
      { ativo: req.body.ativo },
      { new: true }
    );
    res.json(atualizado);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
});

app.delete('/api/produtos/:id', async (req, res) => {
  try {
    await Servico.findOneAndDelete({ id: Number(req.params.id) });
    res.json({ mensagem: 'Serviço removido com sucesso.' });
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
});

/* ==========================================================
   ROTAS DE PEDIDOS E CLIENTES (Checkout, Rastreio e Kanban)
   ========================================================== */


// Cliente faz pedido -> Salva/Atualiza Cliente na coleção 'clientes' + Cria Pedido na coleção 'pedidos'
app.post('/api/pedidos', async (req, res) => {
  try {
    const dadosPedido = req.body;

    // 1. Garante o cadastro/atualização na coleção 'clientes' usando CPF, WhatsApp ou Nome
    if (dadosPedido.cliente && dadosPedido.cliente.nome) {
      const chaveBusca = dadosPedido.cliente.cpf
        ? { cpf: dadosPedido.cliente.cpf }
        : { whatsapp: dadosPedido.cliente.whatsapp };

      await Cliente.findOneAndUpdate(
        chaveBusca,
        {
          nome: dadosPedido.cliente.nome,
          whatsapp: dadosPedido.cliente.whatsapp || 'Não informado',
          email: dadosPedido.cliente.email || '',
          cpf: dadosPedido.cliente.cpf || '',
          endereco: dadosPedido.cliente.endereco || '',
          ultimoPedidoEm: new Date()
        },
        { upsert: true, new: true }
      );
    }

    // 2. Grava o pedido na coleção 'pedidos'
    const pedidoCriado = await Pedido.create(dadosPedido);
    res.status(201).json(pedidoCriado);
  } catch (err) {
    console.error('Erro ao salvar pedido/cliente:', err.message);
    res.status(400).json({ erro: err.message });
  }
});

// Rota utilitária: Extrai todos os clientes dos pedidos já existentes no banco e popula a coleção 'clientes'
app.post('/api/clientes/sincronizar', async (req, res) => {
  try {
    // Remove índices antigos que possam estar travando a coleção clientes
    await Cliente.collection.dropIndexes().catch(() => {});

    const pedidos = await Pedido.find();
    let totalSincronizados = 0;

    for (const p of pedidos) {
      if (p.cliente && p.cliente.nome) {
        const filtro = p.cliente.whatsapp ? { whatsapp: p.cliente.whatsapp } : { nome: p.cliente.nome };
        await Cliente.findOneAndUpdate(
          filtro,
          {
            nome: p.cliente.nome,
            whatsapp: p.cliente.whatsapp || 'Não informado',
            email: p.cliente.email || '',
            cpf: p.cliente.cpf || '',
            endereco: p.cliente.endereco || '',
            ultimoPedidoEm: new Date()
          },
          { upsert: true, new: true }
        );
        totalSincronizados++;
      }
    }
    res.json({ mensagem: `Sucesso! ${totalSincronizados} clientes sincronizados na coleção 'clientes'!` });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

// Listar clientes cadastrados (Admin)
app.get('/api/clientes', async (req, res) => {
  try {
    const clientes = await Cliente.find().sort({ updatedAt: -1 });
    res.json(clientes);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

// Visão Geral de todos os pedidos ativos para a Esteira Kanban (Exclusivo Admin)
app.get('/api/pedidos', async (req, res) => {
  try {
    const pedidos = await Pedido.find({ status: { $ne: 'cancelado' } }).sort({ createdAt: -1 });
    res.json(pedidos);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

// Consulta individual do cliente por código (meu-pedido.html)
app.get('/api/pedidos/:codigo', async (req, res) => {
  try {
    const codigo = req.params.codigo.toUpperCase();
    const pedido = await Pedido.findOne({ codigo });
    if (!pedido) return res.status(404).json({ erro: 'Pedido não encontrado.' });
    res.json(pedido);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

// Avançar ou voltar etapa do pedido no Kanban (Admin)
app.patch('/api/pedidos/:codigo/status', async (req, res) => {
  try {
    const codigo = req.params.codigo.toUpperCase();
    const atualizado = await Pedido.findOneAndUpdate(
      { codigo },
      { status: req.body.status },
      { new: true }
    );
    res.json(atualizado);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
});

// Cancelar pedido a pedido do cliente (Exclusivo Admin)
app.delete('/api/pedidos/:codigo', async (req, res) => {
  try {
    const codigo = req.params.codigo.toUpperCase();
    await Pedido.findOneAndUpdate({ codigo }, { status: 'cancelado' });
    res.json({ mensagem: `Pedido #${codigo} cancelado pelo administrador.` });
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Servidor Full-Stack Lavanderia Alva rodando em http://localhost:${PORT}`);
});
